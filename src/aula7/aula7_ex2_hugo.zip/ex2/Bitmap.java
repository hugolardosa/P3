package aula7.ex2;

public class Bitmap {
	public static BitmapFileHeader bitmapFileHeader;
	public static BitmapInfoHeader bitmapInfoHeader;
	public static byte[] rgbQuad; // color pallete – opcional (ver abaixo)
	public static byte[] data; // pixel data
}